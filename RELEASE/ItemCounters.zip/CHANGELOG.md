`1.0.4`

- Updated for DLC2.
- Now shows void items.

`1.0.3`

- Updated manifest dependencies.

`1.0.2`

- Recompiled for Devotion update.